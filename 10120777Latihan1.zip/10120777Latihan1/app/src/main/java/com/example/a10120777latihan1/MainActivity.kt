package com.example.a10120777latihan1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

/**
 * Muhammad Abi Rafdi Pratama
 * 10120777
 * IF-9
 */
class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
}